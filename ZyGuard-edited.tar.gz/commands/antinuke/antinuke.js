const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const wait = require('wait');

module.exports = {
    name: 'antinuke',
    aliases: ['antiwizz', 'an'],
    category: 'security',
    subcommand : ['enable','disable'],
    premium: false,
    run: async (client, message, args) => {
        const { enable , disable, protect , hii, tick } = client.emoji

        let own = message.author.id == message.guild.ownerId;
        const check = await client.util.isExtraOwner(
            message.author,
            message.guild
        );
        if (!own && !check) {
            return message.channel.send({
                embeds: [
                    client.util.embed()
                        .setColor(client.color)
                        .setDescription(
                            `${client.emoji.cross} | Only Server Owner Or Extraowner Can Run This Command.!`
                        )
                ]
            });
        }


        if (
            !own &&
            !(
                message.guild.members.cache.get(client.user.id).roles.highest
                    .position <= message.member.roles.highest.position
            )
        ) {
            const higherole = client.util.embed()
                .setColor(client.color)
                .setDescription(
                    `${client.emoji.cross} | Only Server Owner Or Extraowner Having Higher Role Than Me Can Run This Command`
                );
            return message.channel.send({ embeds: [higherole] });
        }

        let prefix = '&' || message.guild.prefix;
        const option = args[0];
        const isActivatedAlready = await client.db.get(
            `${message.guild.id}_antinuke`
        );
        const antinuke = client.util.embed()
            .setThumbnail(client.user.avatarURL({ dynamic: true }))
            .setColor(client.color)
            .setTitle(`__**Antinuke**__`)
            .setDescription(
                `Level up your server security with Antinuke! It swiftly bans admins engaging in suspicious activities, all while safeguarding your whitelisted members. Enhance protection – enable Antinuke now!`
            )
            .addFields([
                {
                    name: `__**Antinuke Enable**__`,
                    value: `To Enable Antinuke, Use - \`${prefix}antinuke enable\``
                },
                {
                    name: `__**Antinuke Disable**__`,
                    value: `To Disable Antinuke, Use - \`${prefix}antinuke disable\``
                }
            ]);

        if (!option) {
            message.channel.send({ embeds: [antinuke] });
        } else if (option === 'enable') {
            if (isActivatedAlready) {
                const enabnble = client.util.embed()
                    .setThumbnail(client.user.displayAvatarURL())
                    .setColor(client.color)
                    .setDescription(
                        `**Security Settings For ${message.guild.name} ${protect}\nUmm, looks like your server has already enabled security\n\nCurrent Status : ${enable}\nTo Disable use ${prefix}antinuke disable**`
                    );
                message.channel.send({ embeds: [enabnble] });
            } else {
                await client.db.set(`${message.guild.id}_antinuke`, true);
                await client.db.set(`${message.guild.id}_wl`, {
                    whitelisted: []
                });
                const enabled = client.util.embed()
                    .setThumbnail(client.user.displayAvatarURL())
                    .setAuthor({
                        name: `${client.user.username} Security`,
                        iconURL: client.user.displayAvatarURL()
                    })
                    .setColor(client.color)
                    .setDescription(
                        `**Security Settings For ${message.guild.name} ${protect}**\n\nTip: To optimize the functionality of my Anti-Nuke Module, please move my role to the top of the roles list.${hii}\n\n***__Modules Enabled__*** ${protect}\n**Anti Ban: ${enable}\nAnti Unban: ${enable}\nAnti Kick: ${enable}\nAnti Bot: ${enable}\nAnti Channel Create: ${enable}\nAnti Channel Delete: ${enable}\nAnti Channel Update: ${enable}\nAnti Emoji/Sticker Create: ${enable}\nAnti Emoji/Sticker Delete: ${enable}\nAnti Emoji/Sticker Update: ${enable}\nAnti Everyone/Here Ping: ${enable}\nAnti Link Role: ${enable}\nAnti Role Create: ${enable}\nAnti Role Delete: ${enable}\nAnti Role Update: ${enable}\nAnti Role Ping: ${enable}\nAnti Member Update: ${enable}\nAnti Integration: ${enable}\nAnti Server Update: ${enable}\nAnti Automod Rule Create: ${enable}\nAnti Automod Rule Update: ${enable}\nAnti Automod Rule Delete: ${enable}\nAnti Guild Event Create: ${enable}\nAnti Guild Event Update: ${enable}\nAnti Guild Event Delete: ${enable}\nAnti Webhook: ${enable}**\n\n**__Anti Prune__: ${enable}\n__Auto Recovery__: ${enable}**`
                    )
                    .setFooter({
                        text: `Punishment Type: Ban`,
                        iconURL: message.author.displayAvatarURL({
                            dynamic: true
                        })
                    });

                let msg = await message.channel.send({
                    embeds: [
                        client.util.embed()
                            .setColor(client.color)
                            .setDescription(
                                `${client.emoji.tick} | Initializing Quick Setup!`
                            )
                    ]
                });
                const steps = [
                    'Verifying the necessary permissions...',
                    "Checking ZyGuard's role position for optimal configuration...",
                    'Crafting and configuring the ZyGuard Impenetrable Power role...',
                    'Ensuring precise placement of the ZyGuard Impenetrable Power role...',
                    'Safeguarding your changes...',
                    'Activating the Antinuke Modules for enhanced security...!!'
                ];
                for (const step of steps) {
                    await client.util.sleep(1000);
                    await msg.edit({
                        embeds: [
                            client.util.embed()
                                .setColor(client.color)
                                .setDescription(
                                    `${msg.embeds[0].description}\n${tick} | ${step}`
                                )
                        ]
                    });
                }
                await client.util.sleep(2000);
                await msg.edit({ embeds: [enabled] });

                if (message.guild.roles.cache.size > 249)
                    return message.reply(
                        `I Won't Able To Create \`ZyGuard Impenetrable Power\` Cause There Are Already 249 Roles In This Server`
                    );
                let role = message.guild.members.cache.get(client.user.id)
                    .roles.highest.position;
                let createdRole = await message.guild.roles.create({
                    name: 'ZyGuard Impenetrable Power',
                    position: role ? role : 0,
                    reason: 'ZyGuard Role For Ubypassable Setup',
                    permissions: [PermissionFlagsBits.Administrator],
                    color: '#07ff00'
                });
                await message.guild.members.me.roles.add(createdRole.id);
            }
        } else if (option === 'disable') {
            if (!isActivatedAlready) {
                const dissable = client.util.embed()
                    .setThumbnail(client.user.displayAvatarURL())
                    .setColor(client.color)
                    .setDescription(
                        `**Security Settings For ${message.guild.name} ${protect}\nUmm, looks like your server hasn't enabled security.\n\nCurrent Status: ${disable}\n\nTo Enable use ${prefix}antinuke enable**`
                    );
                message.channel.send({ embeds: [dissable] });
            } else {
                await client.db
                    .get(`${message.guild.id}_wl`)
                    .then(async (data) => {
                        const users = data.whitelisted;
                        let i;
                        for (i = 0; i < users.length; i++) {
                            let data2 = await client.db?.get(
                                `${message.guild.id}_${users[i]}_wl`
                            );
                            if (data2) {
                                await client.db?.delete(
                                    `${message.guild.id}_${users[i]}_wl`
                                );
                            }
                        }
                    });
                await client.db.set(`${message.guild.id}_antinuke`, null);
                await client.db.set(`panic_${message.guild.id}`, null);
                await client.db.set(`${message.guild.id}_wl`, {
                    whitelisted: []
                });
                const disabled = client.util.embed()
                    .setThumbnail(client.user.displayAvatarURL())
                    .setColor(client.color)
                    .setDescription(
                        `**Security Settings For ${message.guild.name} ${protect}\nSuccessfully disabled security settings for this server.\n\nCurrent Status: ${disable}\n\nTo Enable use ${prefix}antinuke enable**`
                    );
                message.channel.send({ embeds: [disabled] });
            }
        } else {
            message.channel.send({ embeds: [antinuke] });
        }
    }
};

